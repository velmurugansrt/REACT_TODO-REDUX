import React, { Component } from 'react';
import '../assets/css/App.css'; 
import { Link } from "react-router-dom";

class App extends Component {

  state = {
    toggle: '1'
  }

  componentWillMount() {
    if (localStorage.getItem("logged") != null) {
      this.props.history.push("/");
    }
  }
  render() {
    return (
      <div className="wrapper fadeInDown">
        <div id="formContent">
          <h2 className={this.state.toggle == "1" ?"active":"inactive underlineHover"} onClick={() => this.setState({ toggle: '1' })}  > Sign In </h2>
          <h2 className={this.state.toggle == "2" ?"active":"inactive underlineHover"} onClick={() => this.setState({ toggle: '2' })}>Sign Up </h2>
          <div className="fadeIn first">
            <img src="http://danielzawadzki.com/codepen/01/icon.svg" id="icon" alt="User Icon" />
          </div>
          {this.state.toggle == "1" ?
            <Login navigation={this.props} /> : <Register toggle={()=>this.setState({toggle:"1"})}  />
          }
        </div>
      </div>
    );
  }
}

class Login extends Component {
  state = {
    mail: '',
    password: '',
  }

  
  login(e) {
    e.preventDefault();
    const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if ( this.state.mail == "") {
      alert("Please enter correct username");
    } else if (this.state.password == "") {
      alert("Please enter password");
    } else {
      var users = localStorage.getItem('users');
      var user_data = { email: this.state.mail, password: this.state.password };
      if (users != null) {
        var old_users = JSON.parse(users);
        var mail = this.state.mail;
        var user_value = old_users.find(function (obj) { return obj.email === mail; });
        if (user_value != undefined) {
          old_users.push(user_data);
          if (user_value.password == this.state.password) {
            var users = localStorage.setItem('logged', JSON.stringify(user_value));
            this.props.navigation.history.push("/");
          } else {
            alert("Password incorrect");
          }
        } else {
          alert("User not found!");
        }
      } else {
        alert("User not found!");
      }
    }
  }

  render() {
    return (
      <div>
        <form>
          <input type="text" id="Username" className="fadeIn second" name="Username" placeholder="Username" value={this.state.mail} onChange={(mail) => this.setState({ mail: mail.target.value })} />
          <input type="password" id="password" className="fadeIn third" name="login" placeholder="password" value={this.state.password} onChange={(password) => this.setState({ password: password.target.value })} />
          <input type="submit" className="fadeIn fourth" value="Sign In" onClick={(e) => this.login(e)} />
        </form>
        <div id="formFooter">
          <a className="underlineHover" href="#">Forgot Password?</a>
        </div>
      </div>

    );
  }

}

class Register extends Component {
 
  state = {
    mail: '',
    password: '',
    repasssword: '',
  }

  singup(e) {
    e.preventDefault();
    const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (this.state.mail == "") {
      alert("Please enter correct username");
    } else if (this.state.password == "") {
      alert("Please enter password");
    } else if (this.state.password != this.state.repasssword) {
      alert("password mismatch");
    } else {
      var users = localStorage.getItem('users');
      var user_id = Math.floor(100000 + Math.random() * 900000);
      var user_data = { user_id: user_id, email: this.state.mail, password: this.state.password };
      if (users != null) {
        var old_users = JSON.parse(users);
        var mail = this.state.mail;
        var user_value = old_users.find(function (obj) { return obj.email === mail; });
        if (user_value == undefined) {
          old_users.push(user_data);
          localStorage.setItem('users', JSON.stringify(old_users));
          this.props.toggle();
          
        } else {
          alert("Sorry User already exist!");
        }
      } else {
        localStorage.setItem('users', JSON.stringify([user_data]));
        this.props.history.push("/");
      }

    }
  }

  render() {
    return (
      <div>
        <form>
          <input type="text" id="Username" className="fadeIn second" name="Username" placeholder="Username" value={this.state.mail} value={this.state.mail} onChange={(mail) => this.setState({ mail: mail.target.value })} />
          <input type="password" id="password" className="fadeIn third" name="login" placeholder="Password" value={this.state.password} onChange={(password) => this.setState({ password: password.target.value })} />
          <input type="password" id="password" className="fadeIn third" name="login" placeholder="Repeat Password" value={this.state.password} value={this.state.repasssword} onChange={(repasssword) => this.setState({ repasssword: repasssword.target.value })} />
          <input type="submit" className="fadeIn fourth" value="Sing Up" onClick={(e) => this.singup(e)} />
        </form>
        <div id="formFooter">
          <a className="underlineHover" href="#">Forgot Password?</a>
        </div>
      </div>

    );
  }

}
export default App;
